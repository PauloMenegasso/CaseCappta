/*
Aqui o JS só começa a trabalhar quando ele recebe o clique do botal mover sondas ou coletar recursos.
Isso facilita o handling do escopo de imputs e a limpeza dos outputs do HTML.
Também vai facilitar a eventual implementação do coletor de recursos.
PS.: Facilitou mesmo!
*/
document.addEventListener('DOMContentLoaded', () => {
  //instanciando o botão de start.
  const StartButton = document.querySelector('#start_btn');
  StartButton.addEventListener('click', () => {
    Start();
  });
  //Esta parte é para a implementação do coletor de recursos.
  const CollectingButton = document.querySelector('#collect_btn');
  CollectingButton.addEventListener('click', () => {
    StartCollecting();
  });
});
//Esta função é o código principal da resolução do Case, recebendo a entrada e gerando a saída.
function Start() {
  //Leitura do valor da textarea com id 'cmd_imput' e divisão do arquivo de entrada nas variáveis.
  let imputText = document.querySelector('#cmd_imput').value;
  let imputTextByLine = imputText.split('\n');
  let gridSize = imputTextByLine[0].split(' ');
  //a soma com 1 aqui é necessária pois a contagem dos eixos começa no zero. Sendo assim, quando a entrada é 5 5, o planalto é 6x6.
  let gridSizeX = parseInt(gridSize[0]) + 1;
  let gridSizeY = parseInt(gridSize[1]) + 1;
  //Definido acima o tamanho do grid, abaixo as coordenadas e direção inicial das sondas
  let InitialCoordenate1 = imputTextByLine[1].split(' ');
  //Aqui optei por dividir as coordenadas em x e y, ao invés de deixá-las como uma lista. Acho que facilitou um pouco,
  //pois pude converter aqui mesmo os valores para o tipo inteiro.
  let InitialCoordenate1X = parseInt(InitialCoordenate1[0]);
  let InitialCoordenate1Y = parseInt(InitialCoordenate1[1]);
  let InitialDirection1 = InitialCoordenate1[2];
  let CoordenateString1 = imputTextByLine[2];
  let InitialCoordenate2 = imputTextByLine[3].split(' ');
  let InitialCoordenate2X = parseInt(InitialCoordenate2[0]);
  let InitialCoordenate2Y = parseInt(InitialCoordenate2[1]);
  let InitialDirection2 = InitialCoordenate2[2];
  let CoordenateString2 = imputTextByLine[4];
  //Agora vamos definir o vetor com as posições possíveis.
  //Vou definí-lo de uma forma que cada giro à esquerda seja incremental e cada giro à direita seja decremental (counterclock).
  let directions = ['N', 'W', 'S', 'E'];
  //Instanciando a variavel de saída que sejá injetada no HTML posteriormente.
  var outputText = '';
  //Criando as listas de entrada para fazer o IgniteProve() (que é a função de comandar as sondas) funcionar com as duas sondas.
  //Obs.: da forma como as variáveis foram definidas, só é possível movimentar uma ou duas sondas. Seria possível movimentar mais
  //criando uma linha no arquivo de entrada que especificasse o número de sondas.
  let CoordinateList = [
    [
      InitialCoordenate1X,
      InitialCoordenate1Y,
      InitialDirection1,
      CoordenateString1,
    ],
    [
      InitialCoordenate2X,
      InitialCoordenate2Y,
      InitialDirection2,
      CoordenateString2,
    ],
  ];
  /*Esta variável cria um array das divs que compoem o grid implementado na fase 2. Este é composto por
  36 divs (6x6) e tem formato quadrado de 180px por 180 px. Cada div entao é 
  representada por um quadrado de 30 px por 30 px, que será definido como width
  abaixo.
  */
  const grid = document.querySelector('.grid');
  //agora vamos definir o layout do planalto baseado no numero dado na entrada:
  //Este comando deve construir o grid apropriadamente tanto para planaltos quadrados como retangulares,
  //embora essa responsividade não possa ser revificada visualmente. Para isso seria necessário atribuir
  //variáveis no CSS, controladas via JS.
  let Layout = [];
  let i = 0;
  if (Layout.length != gridSizeX * gridSizeY) {
    while (i <= gridSizeX) {
      Layout.push(0, 0, 0, 0, 0, 0);
      i++;
    }
  }
  /*Temos para esse caso duas componentes para o layout: ou ele possui uma sonda
  ou não. A sonda é representada pelo 1 enquanto o espaço vazio pelo 0.*/

  const squares = [];
  //function para criar a renderizar o grid.
  function CreateBoard() {
    for (let i = 0; i < Layout.length; i++) {
      const square = document.createElement('div');
      grid.appendChild(square);
      squares.push(square);
    }
  }
  CreateBoard();
  /*Agora vamos mudar o layout conforme a posição da nave:
  O try verifica se as entradas numéricas estão OK. Se houver algum problema nos calculos ele deve acusar erro de entrada.
  Embora isso tenha sido criado para a interface visual, ele deve ser capaz de deter o movimento da sonda, mesmo que sem
  a detecção visual.*/
  try {
    let probeOneInitialIndex =
      gridSizeX * (gridSizeY - 1 - InitialCoordenate1Y) + InitialCoordenate1X;
    let probeTwoInitialIndex =
      gridSizeX * (gridSizeY - 1 - InitialCoordenate2Y) + InitialCoordenate2X;

    DrawProbe(probeOneInitialIndex);
    DrawProbe(probeTwoInitialIndex);
  } catch (error) {
    alert(
      'Foi encontrado um erro. Favor verificar se a entrada está correta. A sonda não se movimentou.'
    );
  }

  function DrawProbe(Index) {
    squares[Index].classList.add('probestart');
  }


  StartProbes();
  function StartProbes() {
    let j = 0;
    while (j <= 1) {
      try {
        IgniteProbe(CoordinateList[j]);

        j++;
      } catch (error) {
        alert(
          'Ocorreu um erro no Starting da probe. Favor verifique a entrada de dados'
        );
      }
    }

    document.querySelector('#cmd_output').innerHTML = outputText;
    //Daqui para baixo foram desenvolvidas as linhas necessárias para acompanhar a posição final das probes. Faz parte da fase2.
    let splitOutputByLine = outputText.split('\n');
    let finalOne = splitOutputByLine[0].split(' ');
    let finalTwo = splitOutputByLine[1].split(' ');
    let FinalCoordenate1X = parseInt(finalOne[0]);
    let FinalCoordenate1Y = parseInt(finalOne[1]);
    let FinalCoordenate2X = parseInt(finalTwo[0]);
    let FinalCoordenate2Y = parseInt(finalTwo[1]);

    let probeOneFinalIndex =
      gridSizeX * (gridSizeY - 1 - FinalCoordenate1Y) + FinalCoordenate1X;
    let probeTwoFinalIndex =
      gridSizeX * (gridSizeY - 1 - FinalCoordenate2Y) + FinalCoordenate2X;
    console.log(probeOneFinalIndex);
    DrawProbeFinal(probeOneFinalIndex);
    DrawProbeFinal(probeTwoFinalIndex);

    function DrawProbeFinal(Index) {
      squares[Index].classList.add('probefinal');
    }
  }

  /*
  A IgniteProbe faz as probes de fato se moverem ou virar. Inicialmente, como 
  temos apenas duas probes, talvez a abordagem via função não fosse necessária,
  mas pensando em escalabilidade, acredito que isso facilite a implementação.
  */

  function IgniteProbe(List) {
    //define a posição e direção da sonda
    let currentPositionX = parseInt(List[0]);
    let currentPositionY = parseInt(List[1]);
    let currentDirection = List[2];
    let i = 0;
    //Aqui percorremos a string de comandos.
    while (i < List[3].length) {
      /*Dentro da string de comandos temos dois comandos comandos possíveis:
      mover (M) ou rotacionar (L ou R). Da forma como a função rotacionar foi 
      desenvolvida, não é necessário escolher entre rotacionar a direita ou a 
      esquerda aqui, pois isso será feito dentro da própria função rotacionar.
      Aqui simplesmente decidimos se a sonda ira se mover ou rotacionar,
      direcionando o programa para as funções MoveProbe e RotateProbe, respectivamente.
      */
      if (List[3][i] == 'M') {
        let moviment = MoveProbe(
          currentPositionX,
          currentPositionY,
          currentDirection
        );
        //aqui ocorre a atualização da posição depois do resultado da função MoveProbe

        currentPositionX = moviment[0];
        currentPositionY = moviment[1];
      } else {
        //aqui ocorre a atualização da direção depois do resultado da função RotateProbe
        currentDirection = RotateProbe(List[3][i], currentDirection);
      }
      i++;
    }
    //Aqui é construído o string que vai ser retornado no output.
    //Ele é construído iterativamente a cada probe movida.
    //Novamente optei por me manter fiel ao formato dos padrões de exemplo do enunciado.
    outputText =
      outputText +
      currentPositionX +
      ' ' +
      currentPositionY +
      ' ' +
      currentDirection +
      '\n';
  }

  /*Aqui temos a função para mover a probe de fato, recebendo posição e direção
  atuais. Nada de especial aqui, ela apenas segue as regras de movimentação.*/
  function MoveProbe(X, Y, Dir) {
    //as tres variáveis abaixo foram definidas para o detector de penhascos.
    let suscesfulMotion = true;
    const initialX = X;
    const initialY = Y;
    if (Dir == 'N') {
      Y = Y + 1;
    }
    if (Dir == 'S') {
      Y = Y - 1;
    }
    if (Dir == 'E') {
      X = X + 1;
    }
    if (Dir == 'W') {
      X = X - 1;
    }
    //Este if é responsável pela probe não cair. Foi implementado durante a fase 3.
    if (X == -1 || X == gridSizeX || Y == -1 || Y == gridSizeY) {
      suscesfulMotion = false;
    }
    if (suscesfulMotion == true) {
      return [X, Y];
    } else {
      alert(
        'A sonda não obteve sucesso na realização do movimento. O movimento foi interrompido para previnir queda!'
      );
      return [initialX, initialY];
    }
  }
  /*Esta é a função de rotação. Estou certo de que há um jeito mais fácil de fazer
isso, mas esse está funcional. Primeiro temos o RotateTo, que vai receber um
'R' ou um 'L', definindo a direção de rotação. Recebemos também a direção atual
da sonda. Percorre-se então o vetor de direções para identificar a 'posição da
direção' (que eu chamei de positionid). O vetor foi construído de modo que,
quando a sonda vira à esquerda, o id aumenta, e quando ela vira para a direita 
ele diminui. Sendo assim é possível controlar a posição fazendo incremento ou 
decremento do id, de maneira bem simples.*/

  function RotateProbe(RotateTo, Dir) {
    for (i in directions) {
      if (Dir == directions[i]) {
        var positionid = i;
      }
    }
    if (RotateTo == 'L') {
      positionid++;
      if (positionid == 4) {
        positionid = 0;
      }
    } else {
      positionid--;
      if (positionid == -1) {
        positionid = 3;
      }
    }
    currentDirection = directions[positionid];
    return currentDirection;
  }
}


/*Esta é a função desenvolvida para o coletor de recursos, que é, a priori, independente da função de mover as probes.
É importante ressaltar que a regra de movimentação nesse código é um pouco diferente da do primeiro. Enquanto no primeiro
o ato da probe rotacionar ou andar não era previamente determinado (pois dependia da string de entrada), aqui ele é feito
de uma maneira mais sequencial: 
  - A probe define se deve rotacionar no eixo X;
  - A probe se movimenta no eixo X;
  - A probe gira uma vez à direita ou a esquerda, para passar a se movimentar no eixo Y;
  - A probe se movimenta em Y e para.
Por isso, funções distintas foram utilizadas nessa parte.
*/
function StartCollecting() {
  //Leitura do valor da textarea 'cmd_imput' e divisão do arquivo de entrada nas variáveis.
  let imputText = document.querySelector('#cmd_imput').value;
  let imputTextByLine = imputText.split('\n');
  let gridSize = imputTextByLine[0].split(' ');
  let initialPosition = imputTextByLine[1].split(' ');
  let initialX = parseInt(initialPosition[0]);
  let initialY = parseInt(initialPosition[1]);
  let initialDir = initialPosition[2];
  let resoursePosition = imputTextByLine[2].split(' ');
  let resourseX = parseInt(resoursePosition[0]);
  let resourseY = parseInt(resoursePosition[1]);
  let displacementMatrix = [[initialX, initialY]];

  //Aqui defini uma função simples para calcular as distâncias. Não sei se era
  //realmente necessário, mas deixou o codigo mais legível para mim.
  function CalculateDistance(ProbePosition, ObjPosition) {
    return ProbePosition - ObjPosition;
  }
  //definição das distâncias.
  let distanceX = CalculateDistance(initialX, resourseX);
  let distanceY = CalculateDistance(initialY, resourseY);
  //os dois loops abaixo são responsáveis pela aproximação da probe ao recurso.
  while (distanceX !== 0) {
    let newParams = moveProbeX(initialX, distanceX, initialDir);
    initialX = newParams[0];
    InitialDir = newParams[1];
    distanceX = CalculateDistance(initialX, resourseX);
    displacementMatrix.push([initialX, initialY]);
  }

  while (distanceY !== 0) {
    newParams = moveProbeY(initialY, distanceY, initialDir);
    initialY = newParams[0];
    initialDir = newParams[1];
    distanceY = CalculateDistance(initialY, resourseY);
    displacementMatrix.push([initialX, initialY]);
  }
  console.log(displacementMatrix);
  /*Função responsavel por mover a probe no eixo X e rotacioná-la.
  Notem que a rotação está bem simples, estou assumindo que existe uma outra
  função (nos moldes da desenvolvida na fase 1, mas não necessariamente igual) que faça essa rotação, e 
  aproveitando aqui apenas seu resultado*/
  function moveProbeX(ProbeXPosition, distance, Direction) {
    if (distance > 0) {
      Direction = 'W';
      ProbeXPosition--;
    } else {
      Direction = 'E';
      ProbeXPosition++;
    }
    return [ProbeXPosition, Direction];
  }
  //Função responsavel por mover a probe no eixo Y e rotacioná-la.
  function moveProbeY(ProbeYPosition, distance, Direction) {
    if (distance > 0) {
      Direction = 'S';
      ProbeYPosition--;
    } else {
      Direction = 'N';
      ProbeYPosition++;
    }
    return [ProbeYPosition, Direction];
  }

  //aqui é simplesmente a construção do retorno.
  var outputText = 'Recursos coletados com sucesso!\n';
  outputText =
    outputText +
    'Posição final da sonda:\n' +
    initialX +
    ' ' +
    initialY +
    ' ' +
    initialDir +
    '\n' +
    'No log do console pode ser encontrada a matriz de deslocamento';

  document.querySelector('#cmd_output').innerHTML = outputText;
}
