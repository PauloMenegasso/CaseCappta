Para desenvolver o Case resolvi utilizar o JavaScript. Como gostaria de criar uma interface gráfica para acompanhar a sonda em uma fase posterior do projeto, acredito que essa seja uma opção adequada.
Dividi o projeto em três fases de desenvolvimento, cada uma representando novas funcionalidades para o projeto.
Na primeira fase teremos o desenvolvimento inicial do projeto de exploração, onde a nave recebera o tamanho inicial do planalto, sua posição e sua sequência de movimentação. Ele deve então realizar seu deslocamento e retornar sua posição final e a direção em que está apontando.
Na segunda fase, desenvolverei uma interface gráfica na web para que o controlador da nave possa acompanhar em tempo real sua movimentação.
Na terceira fase, duas novas funcionalidades serão empenhadas: A primeira é um detector de penhasco, que será capaz de entender se a sonda está 'na beira' do planalto e evitar a movimentação nessa direção se for o caso. Também será implementado um coletor de recursos, que recebe a posição de um recurso e calcula o caminho da sonda até ele, coleta e estaciona a sonda nessa nova posição.
Ainda será realizado o tratamento de erros de entrada não esperadas, que identifiquei como fase X, uma vez que não atribui efetivamente novas funcionalidades à sonda.

Fase 1 - Desenvolvimento Essencial
(X) Desenvolvimento do programa que resolva o problema
(X) Importação dos dados
(X) Trasformação dos dados em variáveis
(X) Definição da função 'Rotate'
(X) Definir um array de direções possível
(X) Definição da função 'Move'
(X) Realização da leitura dos comandos e execução das funções na ordem correta
(X) Exportação dos dados de saída
(X) Começar no Clique do botao

Fase 2 - Desenvolvimento da Interface Gráfica
(X) Desenvolver um HTML que acompanhe a movitação da sonda
(X) Contruir um array de divs para simbolizar o terreno
(X) Um elemento do array vai simbolizar a sonda
(To be Done) Implementação das funções draw e undraw para movimentação
(To be Done) Definir um delay para poder acompanhar a sonda

Fase 3 - Desenvolvimento Adicional
(X) Desenvolver um detector de penhasco
(X) Desenvolver um coletor de recursos otimizado
(X) Este deve receber um recurso e calcular o caminho da sonda até sua posição.
(X) Este recurso não terá representação visual

Fase X - Tratamento de Erros
(X) Erro de entradas inesperadas.

Conclusões do desenvolvimento:

- a fase 1 (case inicial) foi resolvida com sucesso. Resolvi deixar a entrada das variáveis no mesmo formato recebido e construir uma entrada semelhante no coletor de recursos, deixando esse ponto como um desafio adicional de implementação atrelado a uma possível regra de negócio da sonda (teria sido mais fácil, contudo, fazer a entrada de cada uma das variáveis em imputs distintos do HTML).
- na fase 2 (detecção de movimento) não foi possível nesse momento implementar o movimento em tempo real das sondas, entretanto, marcamos no mapa a posições inicial e final delas.
  OBS.: essa feature ainda tem um pequeno problema com a responsividade da página. Por isso, usar uma resolução pequena pode acarretar em problemas na visualização do posicionamento. A vizualização também só funciona corretamente para o tamanho de 6x6 do planalto. Acreito fortemente a solução para resolver isso seja adaptar algumas propriedades do css para que sejam controladas via Js (width e height do grid por exemplo), mas não cheguei a desenvolver efetivamente algo nesse sentido.
- Os dois features da fase 3: reconhecimento de penhasco e coletor de recursos foram implementados completamente.
- Adicionei também os tratamentos de erros de entrada, tanto para a movimentação da sonda como para o coletor de recursos.

Existem ainda algumas pequenas implementações a serem feitas e features à serem melhorados, mas estes se limitam às fases extra de desenvolvimento. O core do software está pronto e devolvendo a saída esperada.
Embora o tempo para o desenvolvimento do case tenha sido bastante generoso, tentei me limitar a utilizar 6 horas de trabalho na sua resolução, para simular a 'pressão' de entregar uma demanda em um prazo relativamente curto. Na realidade passei um pouco do prazo, levando 7h para desenvolver este trabalho. Ainda pensando na filosofia da honestidade, decidi apontar os implementos que não foram realizados de maneira satisfatória dentro da fase 2 (ao invés de simplesmete apagar as linhas do 'to-do').

No geral, achei o case bem divertido de desenvolver. Em alguns momentos eu pensei que não poderia errar qualquer função para não 'perder uma sonda de milhões de dólares em Marte'.

Entrada de dados para o coletor de recursos:
´´´´´´
(tamanho do planalto)
(posiçao e direção da sonda)
(posição de recurso)
´´´´´´

Exemplo:
´´´´´´
5 5
1 2 N
5 4
´´´´´´
